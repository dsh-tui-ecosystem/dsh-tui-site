#!/usr/bin/env python3
"""Play the Deepy whale in a truecolor terminal (half-block characters, 42 cols x 15 rows).

    python3 play.py              # idle, loops until Ctrl-C
    python3 play.py thinking     # one animation
    python3 play.py --all        # tour through all 20
    python3 play.py --list       # list animation keys
    python3 play.py happy --once # play once and exit
"""
import json, os, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))


def load():
    with open(os.path.join(HERE, 'frames.json'), encoding='utf-8') as f:
        data = json.load(f)
    pal = {k: tuple(int(v[i:i + 2], 16) for i in (1, 3, 5)) for k, v in data['palette'].items()}
    return data, pal


def render(rows, pal):
    """rows: list of strings (one char per pixel, '.' = empty) -> list of ANSI lines."""
    lines = []
    for y in range(0, len(rows), 2):
        top = rows[y]
        bot = rows[y + 1] if y + 1 < len(rows) else '.' * len(top)
        s = []
        for a, b in zip(top, bot):
            if a == '.' and b == '.':
                s.append('\x1b[0m ')
            elif a != '.' and b != '.':
                s.append('\x1b[38;2;%d;%d;%dm\x1b[48;2;%d;%d;%dm▀' % (pal[a] + pal[b]))
            elif a != '.':
                s.append('\x1b[0m\x1b[38;2;%d;%d;%dm▀' % pal[a])
            else:
                s.append('\x1b[0m\x1b[38;2;%d;%d;%dm▄' % pal[b])
        lines.append(''.join(s) + '\x1b[0m')
    return lines


def play(anim, pal, once=False, title=True):
    h = None
    loops = 0
    while True:
        for fr in anim['frames']:
            lines = render(fr['rows'], pal)
            if title:
                lines = ['\x1b[2K\x1b[90m  %s · %s\x1b[0m' % (anim['key'], anim['title'])] + lines
            if h is not None:
                sys.stdout.write('\x1b[%dA' % h)
            sys.stdout.write('\n'.join(lines) + '\n')
            sys.stdout.flush()
            h = len(lines)
            time.sleep(fr['dur'] / 1000.0)
        loops += 1
        if once:
            return


def main(argv):
    if os.name == 'nt':
        os.system('')  # enable ANSI escapes on Windows terminals
    data, pal = load()
    by_key = {a['key']: a for a in data['animations']}
    if '--list' in argv:
        for a in data['animations']:
            print('%-12s %s  (%s)' % (a['key'], a['title'], a['trigger']))
        return
    once = '--once' in argv
    keys = [x for x in argv if not x.startswith('--')]
    sys.stdout.write('\x1b[?25l')  # hide cursor
    try:
        if '--all' in argv:
            while True:
                for a in data['animations']:
                    for _ in range(2):
                        play(a, pal, once=True)
                        sys.stdout.write('\x1b[%dA' % 16)
        else:
            key = keys[0] if keys else 'idle'
            if key not in by_key:
                print('unknown animation: %s (use --list)' % key)
                return
            play(by_key[key], pal, once=once)
    except KeyboardInterrupt:
        pass
    finally:
        sys.stdout.write('\x1b[0m\x1b[?25h\n')


if __name__ == '__main__':
    main(sys.argv[1:])
