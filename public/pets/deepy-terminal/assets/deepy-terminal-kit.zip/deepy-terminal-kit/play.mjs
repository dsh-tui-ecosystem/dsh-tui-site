// Deepy whale terminal renderer for Node (ESM, no dependencies).
//   node play.mjs [key] [--once] [--list]
// Or import { loadWhale, renderFrame } into your own CLI / TUI.
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));

export function loadWhale(path = join(here, 'frames.json')) {
  const data = JSON.parse(readFileSync(path, 'utf8'));
  const pal = Object.fromEntries(Object.entries(data.palette).map(([k, v]) =>
    [k, [1, 3, 5].map(i => parseInt(v.slice(i, i + 2), 16))]));
  return { data, pal, byKey: Object.fromEntries(data.animations.map(a => [a.key, a])) };
}

// rows: array of strings, one char per pixel ('.' = empty). Returns ANSI lines (2 pixel rows per line).
export function renderFrame(rows, pal) {
  const lines = [];
  for (let y = 0; y < rows.length; y += 2) {
    const top = rows[y], bot = rows[y + 1] ?? '.'.repeat(top.length);
    let s = '';
    for (let x = 0; x < top.length; x++) {
      const a = top[x], b = bot[x];
      if (a === '.' && b === '.') s += '\x1b[0m ';
      else if (a !== '.' && b !== '.') s += `\x1b[38;2;${pal[a].join(';')}m\x1b[48;2;${pal[b].join(';')}m▀`;
      else if (a !== '.') s += `\x1b[0m\x1b[38;2;${pal[a].join(';')}m▀`;
      else s += `\x1b[0m\x1b[38;2;${pal[b].join(';')}m▄`;
    }
    lines.push(s + '\x1b[0m');
  }
  return lines;
}

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function main(argv) {
  const { data, pal, byKey } = loadWhale();
  if (argv.includes('--list')) {
    for (const a of data.animations) console.log(`${a.key.padEnd(12)} ${a.title}  (${a.trigger})`);
    return;
  }
  const key = argv.find(a => !a.startsWith('--')) ?? 'idle';
  const anim = byKey[key];
  if (!anim) { console.log(`unknown animation: ${key} (use --list)`); return; }
  const once = argv.includes('--once');
  process.stdout.write('\x1b[?25l');
  const restore = () => { process.stdout.write('\x1b[0m\x1b[?25h\n'); process.exit(0); };
  process.on('SIGINT', restore);
  let h = 0;
  do {
    for (const fr of anim.frames) {
      const lines = renderFrame(fr.rows, pal);
      if (h) process.stdout.write(`\x1b[${h}A`);
      process.stdout.write(lines.join('\n') + '\n');
      h = lines.length;
      await sleep(fr.dur);
    }
  } while (!once);
  restore();
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) main(process.argv.slice(2));
